<template>
  <div class="ask_container">
    QA
  </div>
</template>

<script>
export default {};
</script>

<style></style>
