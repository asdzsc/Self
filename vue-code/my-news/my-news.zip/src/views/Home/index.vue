<template>
  <div class="home_container">
    home
  </div>
</template>

<script>
export default {};
</script>

<style></style>
