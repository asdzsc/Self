<template>
  <div class="video_container">
    video
  </div>
</template>

<script>
export default {};
</script>

<style></style>
