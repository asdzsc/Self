<template>
  <div id="app">
    <!-- APP的一级路由出口 路由表中所有的顶层路由都是一级路由-->
    <router-view />
  </div>
</template>
<script>
export default {
  name: "App"
};
</script>
<style lang="scss"></style>
