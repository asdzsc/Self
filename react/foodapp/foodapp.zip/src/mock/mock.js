const hotcate = require("./hotcate.json")
module.exports = () => {
    return {
        hotcate
    }
}