import React, { Component } from 'react'
import {HeadWrap} from './styledCook.js'

export default class Header extends Component {
    render() {
        return (
            <div>
                <HeadWrap>
                美食大全
                </HeadWrap>
            </div>
        )
    }
}
